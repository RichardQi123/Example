<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css">  
	<script src="https://cdn.staticfile.org/jquery/2.1.1/jquery.min.js"></script>
	<script src="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<style type="text/css">
	header span{font-size: 5px;line-height:5px;margin-bottom:10px;padding: 0;display: block;}
</style>
</head>
<body>
	<header style="float: right">
		<h2 style="position: absolute;left:500px;top: 50px">Job / Variations Sheet</h2>
		<img src="images/logo.png" style="width:200px">
		<span>Unit 10, 15 Childs Road, Chipping Norton</span>
		<span>NSW Sydney Australia 2170</span>
		<span>02 9726 4869</span>
		<span>info@xceedelectrical.com.au</span>
		<span><a href="">www.xceedelectrical.com.au</a></span>
	</header>
	<div style="color: both;height: 150px"></div>
<div style="border:1px solid black;padding: 10px">
	<form class="form-horizontal" role="form">
 <table  width="100%" border="0" align="center" cellpadding="1" cellspacing="1" bgcolor="#CCCCCC">
 	<tr>
 		<td><div class="form-group">
    <label for="firstname" class="col-sm-2 control-label">Date:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="firstname" style="width: 80%">
    </div>
  </div></td>
 		
 	</tr>
<tr>
 		<td><div class="form-group">
    <label for="firstname" class="col-sm-2 control-label">Customer Company Name:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="firstname" style="width: 80%">
    </div>
  </div></td>
 		
 	</tr>
 	<tr>
 		<td><div class="form-group">
    <label for="firstname" class="col-sm-2 control-label">Customer Name:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="firstname" style="width: 80%">
    </div>
  </div></td>
 		
 	</tr>
 	<tr>
 		<td><div class="form-group">
    <label for="firstname" class="col-sm-2 control-label">Customer Address:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="firstname" style="width: 80%">
    </div>
  </div></td>
 		
 	</tr>
 	<tr>
 		<td><div class="form-group">
    <label for="firstname" class="col-sm-2 control-label">State:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="firstname" style="width: 80%">
    </div>
  </div></td>
 		
 	</tr>
 	<tr>
 		<td><div class="form-group">
    <label for="firstname" class="col-sm-2 control-label">Post Code:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="firstname" style="width: 80%">
    </div>
  </div></td>
 		
 	</tr>
 	<tr>
 		<td><div class="form-group">
    <label for="firstname" class="col-sm-2 control-label">Phone:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="firstname" style="width: 80%">
    </div>
  </div></td>
 		
 	</tr>
 	<tr>
 		<td><div class="form-group">
    <label for="firstname" class="col-sm-2 control-label">Mobile:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="firstname" style="width: 80%">
    </div>
  </div></td>
 		
 	</tr>
 	<tr>
 		<td><div class="form-group">
    <label for="firstname" class="col-sm-2 control-label">Email:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="firstname" style="width: 80%">
    </div>
  </div></td>
 		
 	</tr>
 	<tr>
 		<td><div class="form-group">
    <label for="firstname" class="col-sm-2 control-label">Website:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="firstname" style="width: 80%">
    </div>
  </div></td>
 		
 	</tr>
 	<tr>
 		<td><div class="form-group">
    <label for="firstname" class="col-sm-2 control-label">ABN:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="firstname" style="width: 80%">
    </div>
  </div></td>
 		
 	</tr>
 	<tr>
 		<td><div class="form-group">
    <label for="firstname" class="col-sm-2 control-label">Job Type:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="firstname" style="width: 80%">
    </div>
  </div></td>
 		
 	</tr>
 	<tr>
 		<td><div class="form-group">
    <label for="firstname" class="col-sm-2 control-label">Order Number:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="firstname" style="width: 80%">
    </div>
  </div></td>
 		
 	</tr>
 	<tr>
 		<td><div class="form-group">
    <label for="firstname" class="col-sm-2 control-label">Job Number:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="firstname" style="width: 80%">
    </div>
  </div></td>
 		
 	</tr>
 	<tr>
 		<td><div class="form-group">
    <label for="firstname" class="col-sm-2 control-label">Site Name:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="firstname" style="width: 80%">
    </div>
  </div></td>
 		
 	</tr>
 	<tr>
 		<td><div class="form-group">
    <label for="firstname" class="col-sm-2 control-label">Site Address:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="firstname" style="width: 80%">
    </div>
  </div></td>
 		
 	</tr>
 	<tr>
 		<td><div class="form-group">
    <label for="firstname" class="col-sm-2 control-label">State:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="firstname" style="width: 80%">
    </div>
  </div></td>
 		
 	</tr>
 	<tr>
 		<td><div class="form-group">
    <label for="firstname" class="col-sm-2 control-label">Post Code:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="firstname" style="width: 80%">
    </div>
  </div></td>
 		
 	</tr>
 	<tr>
 		<td><div class="form-group">
    <label for="firstname" class="col-sm-2 control-label">Variation Date Request:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="firstname" style="width: 80%">
    </div>
  </div></td>
 		
 	</tr>
 	<tr>
 		<td><div class="form-group">
    <label for="firstname" class="col-sm-2 control-label">Representative requesting works:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="firstname" style="width: 80%">
    </div>
  </div></td>
 		
 	</tr>
 </table>
 <center> <button type="button" class="btn">NEXT</button></center>

</form>

</div>
</body>
</html>